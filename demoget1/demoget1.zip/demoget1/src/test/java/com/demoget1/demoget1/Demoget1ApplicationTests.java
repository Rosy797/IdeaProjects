package com.demoget1.demoget1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demoget1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
