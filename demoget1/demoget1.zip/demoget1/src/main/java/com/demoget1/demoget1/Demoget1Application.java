package com.demoget1.demoget1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demoget1Application {

	public static void main(String[] args) {
		SpringApplication.run(Demoget1Application.class, args);
	}

}
