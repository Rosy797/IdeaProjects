package com.demoget1.demoget1.model;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class Employee {

    private int Id;

    private String FirstName;
    private String LastName;
    public  static int getId() {

        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public static String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String firstName) {
        FirstName = firstName;
    }

    public static String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }


    @Override
    public String toString() {
        return "Employee [Id=" + Id + ", FirstName=" + FirstName+ " , Lastname=" + LastName "]";
    }

}
