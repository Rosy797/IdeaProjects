package com.demoget1.demoget1.repository;

import com.demoget1.demoget1.model.Employee;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;


import static com.demoget1.demoget1.model.Employee.*;

@Repository
public class Employeerepository {

    @Autowired
    JdbcTemplate jdbcTemplate;


    public void InsertNewDetailsToDatabase(Employee employee) {
        String sql = "insert into Employee.employee(id,name,lname) values(?,?,?)";
        Object[] params = new Object[]
                {
                        Employee.getId(), Employee.getFirstName(), Employee.getLastName()};
        jdbcTemplate.update(sql, params);
    }

}
