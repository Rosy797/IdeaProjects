import React from 'react';
import ReactDOM from 'react-dom';
import './App.css';
import Xml from './components/Xml';
import  Home  from './components/Home';
import About from './components/About';
import  Profile from './components/Profile';
import Option from './components/Option'
import reportWebVitals from './reportWebVitals'
import {BrowserRouter,Route} from 'react-router-dom'
ReactDOM.render(
<strict mode>
<Xml/>
</strict mode>
   //<BrowserRouter>
  // <Option/>
  // <Route path='/' component={Home} exact/>
  // <Route path='/About' component={About}/>
  // <Route path='/Profile' component={Profile}/>
  // </BrowserRouter>,

  document.getElementById('root')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
