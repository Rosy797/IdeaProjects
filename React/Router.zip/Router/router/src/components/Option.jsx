import React,{Component} from 'react';
import {Link} from 'react-router-dom';
class Option extends Component
{
render()
{
return(
<div>
<h1>Option</h1>
<ul class='nav'>
<li>
<Link to='\'>Home</Link>
</li>
<li>
<Link to='\About'>About</Link>
</li>
<li>
<Link to='\Profile'>Profile</Link>
</li>
</ul>
</div>
)}
}
export default Option;