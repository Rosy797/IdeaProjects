import React,{Component} from 'react';
class Profile extends Component
{
render()
{
return(<h1>profile page</h1>)

}
}
export default Profile;