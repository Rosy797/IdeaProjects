package com.example.demoget.model;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class Employee {

        private String Id;

        private String FirstName;

        public String getEmpId() {
                return Id;
        }

        public void setEmpId(String empId) {
                this.Id = empId;
        }

        public String FirstNameName() {
                return FirstName;
        }

        public void setFirstName(String firstName) {
                this.FirstName = firstName;
        }

        @Override
        public String toString() {
                return "Employee [empId=" + Id + ", FirstName=" + FirstName+ "]";
        }

}

