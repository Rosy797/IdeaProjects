package com.example.demoget;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemogetApplicationTests {

	@Test
	void contextLoads() {
	}

}
